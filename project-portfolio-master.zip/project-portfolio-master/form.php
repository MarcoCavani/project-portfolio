<?php


$name = $_POST["name"];
$email = $_POST["email"];
$message = $_POST["question"];
 
echo "name is: " . $name . "<br>";
echo "email is: " . $email . "<br>";
echo "message is: " .$message . "<br>";

?>